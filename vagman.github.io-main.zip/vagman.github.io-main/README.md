## manousakisvaggelis.com
Μy personal website which I always wanted to build. I will be adding a lot of improvements and changes while I learn new stuff from time to time.

## General Info
* Theme: [Knight theme](https://bootstrapmade.com/knight-free-bootstrap-theme/).
* Images: taken with a [Canon 4000D](https://www.canon.gr/cameras/eos-4000d/specifications/) by myself.